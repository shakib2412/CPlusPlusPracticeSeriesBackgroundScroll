#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"

#define WIDTH  640
#define HEIGHT 480
#define CHARACTER_WIDTH 100  // Approximate width of the character image for boundary checks

int dx, speed;
bool movingRight = true;
bool isPaused = false;

int main()
{
    IMAGE im_bk, img[8];
    initgraph(WIDTH, HEIGHT);

    TCHAR filename[20];

    // Load character images
    for (int i = 0; i < 8; i++)
    {
        _stprintf_s(filename, _T("g%d.png"), i);
        loadimage(&img[i], filename);
    }

    // Load background image
    loadimage(&im_bk, _T("bg.png"));

    int frameIndex = 0;
    dx = 0;
    speed = 5;
    BeginBatchDraw();

    while (1)
    {
        // Check for key presses
        if (_kbhit())  // Detect if a key is pressed
        {
            char key = _getch();
            if (key == 27)  // ESC key to exit
                break;
            else if (key == ' ')  // Space to toggle pause
                isPaused = !isPaused;
        }

        if (!isPaused) // Only update animation if not paused
        {
            // Draw the fixed background
            putimage(0, 0, &im_bk);

            // Display instructions in the top-left corner
            settextcolor(WHITE); // Set text color to white
            settextstyle(16, 0, _T("Arial"));
            outtextxy(10, 10, _T("Press SPACE to pause/resume"));
            outtextxy(10, 30, _T("Press ESC to exit"));

            // Determine direction and display appropriate character frames
            if (movingRight)
            {
                putimagePng(dx, HEIGHT / 2, &img[frameIndex % 4 + 4]); // Use frames g4 to g7 for left to right movement
                dx += speed;
                if (dx + CHARACTER_WIDTH >= WIDTH)  // Check if character reaches the right edge
                {
                    movingRight = false;
                    frameIndex = 0;  // Start from g0 for right to left movement
                }
            }
            else
            {
                putimagePng(dx, HEIGHT / 2, &img[frameIndex % 4]); // Use frames g0 to g3 for right to left movement
                dx -= speed;
                if (dx <= 0)  // Check if character reaches the left edge
                {
                    movingRight = true;
                    frameIndex = 4;  // Start from g4 for left to right movement
                }
            }

            // Update frame index based on direction
            frameIndex = (frameIndex + 1) % 4 + (movingRight ? 4 : 0);
            Sleep(65);
        }
        else
        {
            // Display "Paused" message when animation is paused
            settextcolor(RED); // Set text color to red
            settextstyle(20, 0, _T("Arial"));
            outtextxy(10, 50, _T("Paused"));
        }

        FlushBatchDraw();
    }

    closegraph();
    return 0;
}
