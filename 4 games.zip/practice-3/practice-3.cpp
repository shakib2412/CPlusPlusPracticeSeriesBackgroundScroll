﻿#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"
#include <vector>
#include <tchar.h>

#define WIDTH 640
#define HEIGHT 480
#define HOUSE_WIDTH 560
#define HOUSE_HEIGHT 151
#define HOUSE_SCALE 0.8     
#define NUM_HOUSES_PER_ROW 2 

struct House {
    int x;
    int y;
};

struct Dragon {
    int x;
    int y;
    int frameIndex;
};

int main() {
    // Initialize graphics window
    initgraph(WIDTH, HEIGHT);

    // Image objects
    IMAGE im_bk, im_house;
    IMAGE dragon_frames[8];  // Array for dragon animation frames

    // Load dragon animation frames
    TCHAR filename[20];
    for (int i = 0; i < 8; i++) {
        _stprintf_s(filename, _T("d%d.png"), i + 1);
        loadimage(&dragon_frames[i], filename);
    }

    // Load background and house images with 80% scale
    loadimage(&im_bk, _T("bg.png"));
    loadimage(&im_house, _T("house.png"), HOUSE_WIDTH * HOUSE_SCALE, HOUSE_HEIGHT * HOUSE_SCALE);

    // Define house positions
    int scaledHouseWidth = HOUSE_WIDTH * HOUSE_SCALE;
    int scaledHouseHeight = HOUSE_HEIGHT * HOUSE_SCALE;
    int bottomRowY = HEIGHT - scaledHouseHeight - 10;  // Bottom row Y position
    int upperRowY = bottomRowY - scaledHouseHeight + 20;  // Closer to bottom row

    // Define house arrays for two rows
    House houses[NUM_HOUSES_PER_ROW * 2] = {
        // Bottom row
        {(WIDTH - scaledHouseWidth) / 2 - 200, bottomRowY},
        {(WIDTH - scaledHouseWidth) / 2 + 200, bottomRowY},
        // Upper row (closer to bottom row)
        {(WIDTH - scaledHouseWidth) / 2 - 200, upperRowY},
        {(WIDTH - scaledHouseWidth) / 2 + 200, upperRowY}
    };

    // Vector to store dragons
    std::vector<Dragon> dragons;

    // Populate initial dragons
    for (int i = 0; i < 5; i++) {
        Dragon dragon;
        dragon.x = WIDTH + i * 150;
        dragon.y = 50 + (i % 2) * 50;
        dragon.frameIndex = 0;
        dragons.push_back(dragon);
    }

    const int DRAGON_SPEED = 3;

    BeginBatchDraw();

    while (1) {
        // Draw background
        putimage(0, 0, &im_bk);

        // Draw houses for both rows
        for (int i = 0; i < NUM_HOUSES_PER_ROW * 2; i++) {
            putimagePng(houses[i].x, houses[i].y, &im_house);
        }

        // Update and draw dragons
        for (auto& dragon : dragons) {
            putimagePng(dragon.x, dragon.y, &dragon_frames[dragon.frameIndex]);

            // Move dragon left
            dragon.x -= DRAGON_SPEED;

            // Loop frame index for animation
            dragon.frameIndex = (dragon.frameIndex + 1) % 8;

            // Reset dragon position when off screen
            if (dragon.x < -100) {
                dragon.x = WIDTH + 150;
                dragon.y = 50 + (rand() % 3) * 50;
            }
        }

        Sleep(65);
        FlushBatchDraw();
    }

    int ch = _getch();
    closegraph();
    return 0;
}
